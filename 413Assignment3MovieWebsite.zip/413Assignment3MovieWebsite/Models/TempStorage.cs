﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _413Assignment3MovieWebsite.Models
{
    public class TempStorage
    {

        private static List<AddMovieResponse> movies = new List<AddMovieResponse>();

        public static IEnumerable<AddMovieResponse> Movies => movies;

        public static void AddMovie(AddMovieResponse movie)
        {
            movies.Add(movie);
        }

    }
}
